
<style>
    #main{
        height: 569px;
        width:22%;
        background:gray;
        float: left;
        text-align: center;
    }
    #h6{
        font-size: 25px;
    }
    .row{
        background: orange;
        color: white;
    }
    .btn{
        width:100%;
    }
    label,th,td{
        color:whitesmoke;
    }
    
    
</style>
 <div id="main">
<div class="container">
   
    <?php if(!empty($status)){echo $status;} ?>
    <h6 id="h6"><?php echo "&nbspWelcome&nbsp".$result->name; ?></h6>
    <div class="row">
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('profile');?>" class="btn btn-secondary">Profile</a>
        </div>
    </div>
    <br>
    <div class="row">
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('user/taskdetails');?>" class="btn btn-secondary">Task Details</a>
        </div>
    </div>
    <br>
    <div class="row">
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('user/notification');?>" class="btn btn-secondary">Notification</a>
        </div>
    </div>
    <br>
</div>
</div>

