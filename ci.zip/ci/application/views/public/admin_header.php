 <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User Panel</title>
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/bootstrap.min.css'); ?>">
    <style>
        #logout{
            margin-left: 1160px;
        }
    </style>  
   
</head>    
<body style="background:#434954"> <!--#434954">-->  
   
   <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
       <a class="navbar-brand" href="<?php echo base_url('user/dashboard') ?>">User Panel</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarColor01" aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarColor01">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a id ="logout" class="nav-link" href="<?php echo base_url('user/logout');?>">Logout <span class="sr-only">(current)</span></a>
    </ul>
    
  </div>
</nav> 
