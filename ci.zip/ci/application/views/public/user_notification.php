<?php include('admin_header.php'); ?>  
<style>
    .container{margin-left:10px;
        float: right;
        height: 100%;
        width:1050px;
    }
    .shift{
        margin-left: 290px;
    }
    #btn1{
        width:150px;
        height: 40px;
        text-align: center;
        float: left;
    }
    label,th,td{
        color:whitesmoke;
    }
    #main{
        
        width:21%;
        background:gray;
        float: left;
        height: 1123px;
        text-align: center;
    }
    #h6{
        font-size: 25px;
    }
    .row1{
        background: orange;
        width:100;
        color: white;
    }
    .btn{
       width:145px;
    }
    #id{
        float:left;
        width:80px;
    }
     #comp{
        width:145px;
    }
    
</style>
 <div id="main">

   
    <?php if(!empty($status['status'])){echo $status['status'];} ?>
    <h6 id="h6"><?php echo "&nbspWelcome&nbsp".$result2->name; ?></h6>
    <div class="row1">
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('user/profile');?>" class="btn btn-secondary">Profile</a>
        </div>
    </div>
    
    <br>
    <div class="row1">
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('user/taskdetails');?>" class="btn btn-secondary">My Tasks</a>
        </div>
    </div>
    <br>
    <div class="row1">
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('user/assigned_task');?>" class="btn btn-secondary">Task Details</a>
        </div>
    </div>
    <br>
    <div class="row1">
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('user/completed_task');?>" class="btn btn-secondary" id="comp">Completed Tasks</a>
        </div>
    </div>
    <br>
    <div class="row1">
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('user/notification');?>" class="btn btn-secondary">Notification</a>
        </div>
    </div>
    <br>
    <div class="row1">
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('user/request_send');?>" class="btn btn-secondary">Request</a>
        </div>
    </div>
</div>

<div class="container">
    
    <table class="table">
        <thead>
            <th>Sr.No.</th>
            <th>Title</th>
            <th>Description</th>
            <th>Posted At</th>
        </thead>
        <tbody>
             <?php $val = 1; if(count($result)){
             ?>
           
              <?php  foreach ($result as $res){ ?>
            <tr>
                <td><?php echo $val; ?></td>
                <td><?php echo $res->title; ?></td>
                <td><?php echo $res->body; ?></td>
                <td><?php echo $res->create_at; ?></td>
                
            </tr>
             <?php $val++; } ?>
             <?php } else{ ?>
             <tr>
                <td colspan="3">No Records Found.</td> 
             </tr>
             <?php } ?>       
        </tbody>
    </table>
</div>
<?php include('admin_footer.php'); ?>  