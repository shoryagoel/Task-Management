<?php include('admin_header.php'); ?>

<style>
    #main{
        height: 569px;
        width:22%;
        background:gray;
        float: left;
        text-align: center;
    }
    #h6{
        font-size: 25px;
    }
    .row{
        background: orange;
        color: white;
    }
    .btn{
       width:145px;
    }
    label,th,td{
        color:whitesmoke;
    }
     #comp{
        width:145px;
    }
    
    
</style>
 <div id="main">
<div class="container">
   
    <?php if(!empty($status)){echo $status;} ?>
    <h6 id="h6"><?php echo "&nbspWelcome&nbsp".$result->name; ?></h6>
    <div class="row">
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('user/profile');?>" class="btn btn-secondary">Profile</a>
        </div>
    </div>
    <br>
    <div class="row">
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('user/taskdetails');?>" class="btn btn-secondary">My Tasks</a>
        </div>
    </div>
    <br>
    <div class="row">
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('user/assigned_task');?>" class="btn btn-secondary">Task Details</a>
        </div>
    </div>
    <br>
    <div class="row">
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('user/completed_task');?>" class="btn btn-secondary" id="comp">Completed Tasks</a>
        </div>
    </div>
    <br>
    <div class="row">
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('user/notification');?>" class="btn btn-secondary">Notifications</a>
        </div>
    </div>
    
    <br>
    <div class="row">
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('user/request_send');?>" class="btn btn-secondary">Request</a>
        </div>
    </div>
</div>
</div>



<?php include('admin_footer.php'); ?>