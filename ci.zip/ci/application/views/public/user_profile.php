<?php include('admin_header.php'); ?>

<style>
    #main{
        height: 569px;
        width:21%;
        background:gray;
        float: left;
        text-align: center;
        
    }
    #h6{
        font-size: 25px;
    }
    .row{
        background: orange;
        color: white;
    }
    .btn{
       width:145px;
    }
    label,th,td{
        color:whitesmoke;
    }
    .container{
        height:100%;
        width:100%;
    }
    .container1{margin-left:10px;
        float: right;
        height: 100%;
        width:1050px;
    }
     #comp{
        width:145px;
    }
</style>
 <div id="main">
<div class="container">
   
    <?php if(!empty($status)){echo $status;} ?>
    <h6 id="h6"><?php echo "&nbspWelcome&nbsp".$result->name; ?></h6>
    <div class="row">
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('user/profile');?>" class="btn btn-secondary">Profile</a>
        </div>
    </div>
    <br>
    <div class="row">
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('user/taskdetails');?>" class="btn btn-secondary">My Tasks</a>
        </div>
    </div>
    <br>
    <div class="row">
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('user/assigned_task');?>" class="btn btn-secondary">Task Details</a>
        </div>
    </div>
    <br>
    <div class="row">
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('user/completed_task');?>" class="btn btn-secondary" id="comp">Completed Tasks</a>
        </div>
    </div>
    <br>
    <div class="row">
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('user/notification');?>" class="btn btn-secondary">Notification</a>
        </div>
    </div>
    <br>
    <div class="row">
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('user/request');?>" class="btn btn-secondary">Request</a>
        </div>
    </div>
    
</div>
</div>

<div class="container1">
    <h2>Profile</h2>
   <table class="table">
        <tbody>
            <tr>
                <td>Username:</td>
                <td><?php echo $result->name; ?></td>
            </tr>
            <tr>
                <td>Gender:</td>
                <td><?php echo $result->gender;?></td>
            </tr>
            <tr>
                <td>Designation:</td>
                <td><?php echo $result->designation; ?></td>
            </tr>
            <tr>
                <td>DOB:</td>
                <td><?php echo $result->dob; ?></td>
            </tr>
            <tr>
                <td>City:</td>
                <td><?php echo $result->city; ?></td>
            </tr>
            <tr>
                <td>Permanent Address:</td>
                <td><?php echo $result->permanent_address; ?></td>
            </tr>
            <tr>
                <td>Temporary Address:</td>
                <td><?php echo $result->temporary_address; ?></td>
            </tr>
            <tr>
                <td>Email:</td>
                <td><?php echo $result->email; ?></td>
            </tr>
            
<!--            <tr>
                <td>
                    <?php echo anchor("login/editprofile/{$result->id}",'Edit',['class'=>"btn btn-primary",'id'=>'btn1']); ?>
                </td>
            </tr>       -->
        </tbody>
    </table>
</div>

<?php include('admin_footer.php'); ?>