<?php include('admin_header.php'); ?>  
<style>
    .container{margin-left:10px;
        float: right;
        height: 100%;
        width:1050px;
    }
    .shift{
        margin-left: 290px;
    }
    #btn1{
        width:150px;
        height: 40px;
        text-align: center;
        float: left;
    }
    label,th,td{
        color:whitesmoke;
    }
    #main{
        
        width:21%;
        background:gray;
        float: left;
        height:570px;
        text-align: center;
    }
    #h6{
        font-size: 17px;
    }
    .row1{
        background: orange;
        width:100;
        color: white;
    }
    .btn{
      width:145px;
    }
    #id{
        float:left;
        width:80px;
    }
    #comp{
        width:145px;
    }
    
</style>
 <div id="main">

   
    <?php if(!empty($status['status'])){echo $status['status'];} ?>
    <h4><?php echo "&nbspWelcome&nbsp".$result2->name; ?></h4>
    <div class="row1">
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('user/profile');?>" class="btn btn-secondary" class="com">Profile</a>
        </div>
    </div>
    
    <br>
    <div class="row1">
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('user/taskdetails');?>" class="btn btn-secondary" class="com">My Tasks</a>
        </div>
    </div>
    <br>
    <div class="row1">
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('user/assigned_task');?>" class="btn btn-secondary" class="com">Task Details</a>
        </div>
    </div>
    <br>
    <div class="row1">
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('user/completed_task');?>" class="btn btn-secondary" id="comp">Completed Tasks</a>
        </div>
    </div>
    <br>
    <div class="row1">
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('user/notification');?>" class="btn btn-secondary" class="com">Notification</a>
        </div>
    </div>
    <br>
    <div class="row1">
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('user/request_send');?>" class="btn btn-secondary" class="com">Request</a>
        </div>
    </div>
</div>

<div class="container">
    
    <?php echo form_open('user/do_assigntask'); ?>
  <fieldset>
    <legend>Assign Task</legend>
    
   <div class="row">
            <div class="col-lg-6">
    <div class="form-group">
        <label for="exampleInputEmail1">Title:</label>
      <?php echo form_input(['name'=>'title','type'=>'text','class'=>'form-control','id'=>'exampleInputEmail1','placeholder'=>"Enter Task Title"]);?>
      <?php if(!empty($error['title'])){echo $error['title'];} ?>
    </div>
    <div class="form-group">
      <label for="exampleInputEmail1">Description:</label> 
      <?php echo form_textarea(['name'=>'description','type'=>'text','class'=>'form-control','id'=>'exampleInputEmail1','placeholder'=>"Enter Task Description"]);?>
      <?php if(!empty($error['description'])){echo $error['description'];} ?>
    </div>
    <div class="form-group">
      <label for="exampleInputEmail1">Assign To:</label>
      <select name='assigned_to'>
          <?php if(count($result)){ ?>
          <?php foreach ($result as $res){ ?>
          <?php if($result2->email!=$res->email){?>
          <option value="<?php echo $res->employee_id; ?>"><?php echo $res->name; ?></option>
          <?php }}} ?>
      </select>
      <?php if(!empty($error['assigned_to'])){echo $error['assigned_to'];} ?>
    </div>
    <div class="form-group">
    <label for="exampleInputEmail1">Priority:</label> 
    <select name='priority'>
        <?php $data = array('Low','Medium','High');?>
        <?php foreach($data as $d){ ?>
        <option value="<?php echo $d; ?>"><?php echo $d; ?></option>
        <?php } ?>
    </select>
    <?php if(!empty($error['priority'])){echo $error['priority'];} ?>
    </div>
    <?php echo form_submit(['name' => 'Submit', 'value' => 'Assign', 'class' => 'btn btn-primary','id'=>'btn1']); ?>
    <?php echo form_close(); ?>
    </div>
   </div>
</div>
<?php include('admin_footer.php'); ?>  