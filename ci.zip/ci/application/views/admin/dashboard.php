 <?php include('admin_header.php'); ?> 
<style>
    #main{
        height: 569px;
        width:22%;
        background:gray;
        float: left;
        text-align: center;
    }
    #h6{
        font-size: 17px;
    }
    .row{
        background: orange;
        color: white;
    }
    .btn{
        width:100%;
    }
    label,th,td{
        color:whitesmoke;
    }
    
    
</style>
 <div id="main">
<div class="container">
   
    <?php if(!empty($status)){echo $status;} ?>
    <h6 id="h6"><img src=<?php echo base_url("uploads/".$result->image); ?> width=70 height="50"><?php echo "&nbspWelcome&nbsp".$result->username; ?></h6>
    <div class="row">
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('profile');?>" class="btn btn-secondary">Profile</a>
        </div>
    </div>
    <br>
    <div class="row">
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('login/userpanel');?>" class="btn btn-secondary">User Panel</a>
        </div>
    </div>
    <br>
    <div class="row">
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('login/taskdetails');?>" class="btn btn-secondary">Task Details</a>
        </div>
    </div>
    <br>
    <div class="row">
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('login/notification');?>" class="btn btn-secondary">Notification</a>
        </div>
    </div>
    <br>
    <div class="row">
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('login/request');?>" class="btn btn-secondary">Requests</a>
        </div>
    </div>
    <br>
    <div class="row">
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('login/designation');?>" class="btn btn-secondary">Designation</a>
        </div>
    </div>
</div>
</div>

<?php include('admin_footer.php'); ?>  