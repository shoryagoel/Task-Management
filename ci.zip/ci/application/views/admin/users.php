<?php include('admin_header.php'); ?> 
<style>
    .container{
        float: right;
        width:1050px;
    }
</style>
<style>
    #main{
        height: 569px;
        width:22%;
        background:gray;
        float: left;
        text-align: center;
    }
    #h6{
        font-size: 17px;
    }
    .row1{
        background: orange;
        width:100;
        color: white;
    }
    .btn{
        width:100%;
    }
    #id{
        float:left;
        width:80px;
    }
    #btn1{
        width:150px;
        height: 40px;
        text-align: center;
        float: right;
    }
    label,th,td{
        color:whitesmoke;
    }
    
</style>
 <div id="main">

   
    <?php if(!empty($status['status'])){echo $status['status'];} ?>
    <h6 id="h6"><img src=<?php echo base_url("uploads/".$result2->image); ?> width=70 height="50"><?php echo "&nbspWelcome&nbsp".$result2->username; ?></h6>
    <div class="row1">
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('profile');?>" class="btn btn-secondary">Profile</a>
        </div>
    </div>
    <br>
    <div class="row1" >
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('login/userpanel');?>" class="btn btn-secondary">User Panel</a>
        </div>
    </div>
    <br>
    <div class="row1">
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('login/taskdetails');?>" class="btn btn-secondary">Task Details</a>
        </div>
    </div>
    <br>
    <div class="row1">
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('login/notification');?>" class="btn btn-secondary">Notification</a>
        </div>
    </div>
    <br>
    <div class="row1">
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('login/request');?>" class="btn btn-secondary">Requests</a>
        </div>
    </div>
    <br>
    <div class="row1">
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('login/designation');?>" class="btn btn-secondary">Designation</a>
        </div>
    </div>
</div>
<div class="container">
     <?php if(!empty($block)){echo $block;} ?>
     <?php if(!empty($edit)){echo $edit;} ?>
    <?php if(!empty($delete)){ echo $delete; } ?>
    <?php echo anchor("login/adduser",'Add User',['class'=>"btn btn-primary",'id'=>'btn1']); ?>
    <?php if(!empty($status['status'])){ echo $status['status'] ; }?>
    <table class="table">
        <thead>
            <th>Sr.No.</th>
            <th>Name</th>
<!--            <th>Gender</th>-->
            <th>Designation</th>
            <th>DOB</th>
            <th>City</th>
<!--            <th>Permanent Address</th>
            <th>Temporary Address</th>-->
            <th>Email</th>
            <th>Password</th>
<!--            <th>Block</th>-->
            <th>Action</th>
        </thead>
        <tbody>
             <?php $val = 1; if(count($result)){?>
              <?php  foreach ($result as $res){ ?>
            <tr>
                <td><?php echo $val; ?></td>
                <td><?php echo $res->name; ?></td>
<!--                <td><?php echo $res->gender; ?></td>-->
                <td><?php echo $res->designation; ?></td>
                <td><?php echo $res->dob; ?></td>
                <td><?php echo $res->city; ?></td>
<!--                <td><?php echo $res->permanent_address; ?></td>
                <td><?php echo $res->temporary_address; ?></td>-->
                <td><?php echo $res->email; ?></td>
                <td><?php echo $res->password; ?></td>
<!--                <td><?php echo $res->block; ?></td>-->
                <td>
                    <div class="row">
                        <div class="col-lg-4">
                            <?php echo anchor("login/edituser/{$res->employee_id}",'Edit',['class'=>"btn btn-primary"]); ?>
                        </div>
                    
                        <?php if($res->block==0){ ?>
                        <div class="col-lg-4">
                             <?php $block=1; ?>
                            
                            <?php echo anchor("login/block/{$res->employee_id}/{$block}",'Block',['class'=>"btn btn-danger"]); ?>
                        </div> <?php }?>
                        <?php if($res->block==1){ ?>
                        <div class="col-lg-4">
                            <?php $block=0; ?>
                              
                            <?php echo anchor("login/block/{$res->employee_id}/{$block}",'Unblock',['class'=>"btn btn-primary"]); ?>
                        </div> <?php }?>
                        
                        <div class="col-lg-4">
                            <?php echo form_open('login/deleteuser');
                            echo form_hidden('employee_id',$res->employee_id);
                             //echo anchor("admin/delete_article",'Delete',['class'=>"btn btn-danger"]);
                            echo form_submit(['name'=>'submit','value'=>'Delete','class'=>'btn btn-danger','onclick'=>"return confirm('Are you sure?')"]);
                            echo form_close();?>
                        </div>
                    </div>
                </td>
            </tr>
             <?php $val++; } ?>
             <?php } else{ ?>
             <tr>
                <td colspan="3">No Records Found.</td> 
             </tr>
             <?php } ?>       
        </tbody>
    </table>
</div>
<?php include('admin_footer.php'); ?>  