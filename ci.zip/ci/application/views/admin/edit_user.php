<?php include('admin_header.php'); ?>
<style>
    .container{margin-left:10px;
        float: right;
        height: 100%;
        width:1050px;
    }
    .shift{
        margin-left: 290px;
    }
#btn1{
        width:150px;
        height: 40px;
        text-align: center;
        float: left;
    }
    #main{
        
        width:21%;
        background:gray;
        float: left;
        height: 1123px;
        text-align: center;
    }
    #h6{
        font-size: 17px;
    }
    .row1{
        background: orange;
        width:100;
        color: white;
    }
    .btn{
        width:100%;
    }
    #id{
        float:left;
        width:80px;
    }
    label,th,td{
        color:whitesmoke;
    }
    
</style>
 <div id="main">

   
    <?php if(!empty($status['status'])){echo $status['status'];} ?>
    <h6 id="h6"><img src=<?php echo base_url("uploads/".$result2->image); ?> width=70 height="50"><?php echo "&nbspWelcome&nbsp".$result2->username; ?></h6>
    <div class="row1">
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('profile');?>" class="btn btn-secondary">Profile</a>
        </div>
    </div>
    <br>
    <div class="row1" >
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('login/userpanel');?>" class="btn btn-secondary">User Panel</a>
        </div>
    </div>
    <br>
    <div class="row1">
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('login/taskdetails');?>" class="btn btn-secondary">Task Details</a>
        </div>
    </div>
    <br>
    <div class="row1">
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('login/notification');?>" class="btn btn-secondary">Notification</a>
        </div>
    </div>
    <br>
    <div class="row1">
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('login/request');?>" class="btn btn-secondary">Requests</a>
        </div>
    </div>
    <br>
    <div class="row1">
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('login/designation');?>" class="btn btn-secondary">Designation</a>
        </div>
    </div>
</div>

<div class="container">

  <?php echo form_open('login/do_edituser'); ?>
  <?php echo form_hidden('employee_id',$result->employee_id); ?>
      
  <fieldset>
    <legend>Edit User</legend>
   
    <?php   // print_r($result);die;S?>
   <div class="row">
            <div class="col-lg-6">
    <div class="form-group">
      <label for="exampleInputEmail1">Name:</label>
      <!--<input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Username">-->
      <?php echo form_input(['name'=>'name','type'=>'text','class'=>'form-control','id'=>'exampleInputEmail1','value'=> set_value('name',$result->name),'placeholder'=>"Enter User Name"]);?>
      <?php if(!empty($error['name'])){echo $error['name'];} ?>
    </div>
    <div class="form-group">
      <label for="exampleInputEmail1">Gender</label>
      <!-- <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter First Name"> -->
      <select name='gender' value="<?php echo $result->gender; ?>">
          <option>Male</option>
          <option>Female</option>
          <option>Others</option>
      </select>
      <?php if(!empty($error['gender'])){echo $error['gender'];} ?>
    </div> 
        
    <div class="form-group">
      <label for="exampleInputEmail1">Designation</label>
      
      <select name="designation">
          <?php if(count($desig)){?>
          <?php foreach($desig as $d){ ?>
                  <option value="<?php echo $d->id;?>" <?php if($d->id==$result->id){echo "selected";}?>>
              <?php echo $d->name; ?>
          </option>
          <?php }}?>
      </select>
       
      <?php if(!empty($error['designation'])){echo $error['designation'];} ?>
      <!--<input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Last Name">-->
    </div>
       
    <div class="form-group">
      <label for="exampleInputPassword1">DOB</label>
      <?php echo form_input(['name'=>'dob','type'=>'date','class'=>'form-control','value'=> set_value('dob',$result->dob),'id'=>'exampleInputEmail1']);?>
      <?php if(!empty($error['dob'])){echo $error['dob'];} ?>
      <!-- <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Enter Password">-->
    </div>
    <div class="form-group">
      <label for="exampleInputPassword1">City</label>
      <?php echo form_input(['name'=>'city','type'=>'text','class'=>'form-control','id'=>'exampleInputEmail1','value'=> set_value('city',$result->city),'placeholder'=>"Enter your city"]);?>
      <?php if(!empty($error['city'])){echo $error['city'];} ?>
      <!-- <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Enter Password">-->
    </div>
    <div class="form-group">
      <label for="exampleInputPassword1">Permanent Address</label>
      <?php echo form_textarea(['name'=>'permanent_address','type'=>'text','class'=>'form-control','value'=> set_value('permanent_address',$result->permanent_address),'id'=>'exampleInputEmail1','placeholder'=>"Enter Permanent Address"]);?>
      <?php if(!empty($error['permanent_address'])){echo $error['permanent_address'];} ?>
      <!-- <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Enter Password">-->
    </div>
    <div class="form-group">
      <label for="exampleInputPassword1">Temporary Address</label>
      <?php echo form_textarea(['name'=>'temporary_address','type'=>'text','class'=>'form-control','value'=> set_value('temporary_address',$result->temporary_address),'id'=>'exampleInputEmail1','placeholder'=>"Enter Temporary Address"]);?>
      <?php if(!empty($error['temporary_address'])){echo $error['temporary_address'];} ?>
      <!-- <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Enter Password">-->
    </div>
    <div class="form-group">
      <label for="exampleInputPassword1">Email Id</label>
      <?php if(!empty($error['email'])){echo $error['email'];} ?>
      <?php echo form_input(['name'=>'email','type'=>'email','class'=>'form-control','value'=> set_value('email',$result->email),'id'=>'exampleInputEmail1','placeholder'=>"Enter Email Id"]);?>
      <?php if(!empty($error['email'])){echo $error['email'];} ?>
      <!-- <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Enter Password">-->
    </div> 
    
    <div class="form-group">
      <label for="exampleInputPassword1">Password</label>
      <?php echo form_password(['name'=>'password','type'=>'password','class'=>'form-control','value'=> set_value('password',$result->password),'id'=>'exampleInputEmail1','placeholder'=>"Enter Password"]);?>
      <?php if(!empty($error['password'])){echo $error['password'];} ?>
      <!-- <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Enter Password">-->
    </div>            
            </div>
       
   </div>
    <div class="form-group">
        <?php echo form_submit(['name' => 'Submit', 'value' => 'Register', 'class' => 'btn btn-primary','id'=>'btn1']); ?>
    </div>
    <!-- <button type="submit" class="btn btn-primary">Submit</button> -->
  </fieldset>
<?php form_close();?>
</div>
<?php include('admin_footer.php'); ?>
