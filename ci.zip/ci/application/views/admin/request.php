<?php include('admin_header.php'); ?> 
<style>
    .container{margin-left:10px;
        float: right;
        height: 100%;
        width:1050px;
    }
    .shift{
        margin-left: 290px;
    }
</style>
<style>
    #main{
        
        width:21%;
        background:gray;
        float: left;
        height: 1123px;
        text-align: center;
    }
    #h6{
        font-size: 17px;
    }
    .row1{
        background: orange;
        width:100;
        color: white;
    }
    .btn{
        width:100%;
    }
    #id{
        float:left;
        width:80px;
    }
    label,th,td{
        color:whitesmoke;
    }
    
</style>
 <div id="main">

   
    <?php if(!empty($status['status'])){echo $status['status'];} ?>
    <h6 id="h6"><img src=<?php echo base_url("uploads/".$result2->image); ?> width=70 height="50"><?php echo "&nbspWelcome&nbsp".$result2->username; ?></h6>
    <div class="row1">
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('profile');?>" class="btn btn-secondary">Profile</a>
        </div>
    </div>
    <br>
    <div class="row1" >
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('login/userpanel');?>" class="btn btn-secondary">User Panel</a>
        </div>
    </div>
    <br>
    <div class="row1">
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('login/taskdetails');?>" class="btn btn-secondary">Task Details</a>
        </div>
    </div>
    <br>
    <div class="row1">
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('login/notification');?>" class="btn btn-secondary">Notification</a>
        </div>
    </div>
    <br>
    <div class="row1">
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('login/request');?>" class="btn btn-secondary">Requests</a>
        </div>
    </div>
    <br>
    <div class="row1">
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('login/designation');?>" class="btn btn-secondary">Designation</a>
        </div>
    </div>
</div>


<div class="container">
  
    <table class="table">
        <thead>
            <th>Sr.No.</th>
            <th>Subject</th>
            <th>Description</th>
            <th>Sent To</th>
            <th>Date</th>
        </thead>
        <tbody>
             <?php $val = 1; if(count($result)){
             ?>
           
              <?php  foreach ($result as $res){ ?>
            <tr>
                <td><?php echo $val; ?></td>
                <td><?php echo $res->subject; ?></td>
                <td><?php echo $res->description; ?></td>
                <td><?php echo $res->name; ?></td>
                <td><?php echo $res->date; ?></td>
            </tr>
             <?php $val++; } ?>
             <?php } else{ ?>
             <tr>
                <td colspan="3">No Records Found.</td> 
             </tr>
             <?php } ?>       
        </tbody>
    </table>
</div>
<?php include('admin_footer.php'); ?> 