 <?php include('admin_header.php'); ?> 
<style>
    #main{
        height: 569px;
        width:22%;
        background:gray;
        float: left;
        text-align: center;
    }
    #h6{
        font-size: 17px;
    }
    .row{
        background: orange;
        color: white;
    }
    .btn{
        width:100%;
    }
    label,th,td{
        color:whitesmoke;
    }
    #btn1{
        margin-left:20px;
        width: 115px;
        float: left;
    }
    .shift{
        width:500px;
        float:left;
        margin-left:10px
    }
    
</style>
 <div id="main">
<div class="container">
   
    <h6 id="h6"><img src=<?php echo base_url("uploads/".$result2->image); ?> width=70 height="50"><?php echo "&nbspWelcome&nbsp".$result2->username; ?></h6>
    <div class="row">
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('profile');?>" class="btn btn-secondary">Profile</a>
        </div>
    </div>
    <br>
    <div class="row">
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('login/userpanel');?>" class="btn btn-secondary">User Panel</a>
        </div>
    </div>
    <br>
    <div class="row">
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('login/taskdetails');?>" class="btn btn-secondary">Task Details</a>
        </div>
    </div>
    <br>
    <div class="row">
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('login/notification');?>" class="btn btn-secondary">Notification</a>
        </div>
    </div>
    <br>
    <div class="row">
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('login/request');?>" class="btn btn-secondary">Requests</a>
        </div>
    </div>
    <br>
    <div class="row">
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('login/designation');?>" class="btn btn-secondary">Designation</a>
        </div>
    </div>
</div>
</div>

<div class="container" id="container1">
    <div class="shift">
<?php echo form_open('login/do_edit_desig'); ?>
<?php echo form_hidden('id',$result->id); ?>

  <fieldset>
    <legend>Edit Designation</legend>
    
   <div class="row1">
            <div class="col-lg-6">
    <div class="form-group">
      <label for="exampleInputEmail1">Name:</label>
      <!--<input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Username">-->
      <?php echo form_input(['name'=>'name','type'=>'text','class'=>'form-control','id'=>'exampleInputEmail1','placeholder'=>"Enter User Name",'value'=> set_value('name',$result->name)]);?>
      <?php if(!empty($error['name'])){echo $error['name'];} ?>
    </div>
            </div>
       
        </div>
    <div class="form-group">
        <?php echo form_submit(['name' => 'Submit', 'value' => 'Save Changes', 'class' => 'btn btn-primary','id'=>'btn1']); ?>
    </div>
  </fieldset>
</form>
</div>
    </div>
<?php include('admin_footer.php'); ?>  