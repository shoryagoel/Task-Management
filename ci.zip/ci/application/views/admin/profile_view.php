 <?php include('admin_header.php'); ?>  
<style>
    .container{margin-left:10px;
        float: right;
        height: 100%;
        width:1050px;
    }
    .shift{
        margin-left: 290px;
    }
    #btn1{
        width:150px;
        height: 40px;
        text-align: center;
        float: left;
    }
    label,th,td{
        color:whitesmoke;
    }
    #main{
        
        width:21%;
        background:gray;
        float: left;
        height: 1123px;
        text-align: center;
    }
    #h6{
        font-size: 17px;
    }
    .row1{
        background: orange;
        width:100;
        color: white;
    }
    .btn{
        width:100%;
    }
    #id{
        float:left;
        width:80px;
    }
    
    
</style>
 <div id="main">

   
    <?php if(!empty($status['status'])){echo $status['status'];} ?>
    <h6 id="h6"><img src=<?php echo base_url("uploads/".$result2->image); ?> width=70 height="50"><?php echo "&nbspWelcome&nbsp".$result2->username; ?></h6>
    <div class="row1">
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('profile');?>" class="btn btn-secondary">Profile</a>
        </div>
    </div>
    <br>
    <div class="row1" >
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('login/userpanel');?>" class="btn btn-secondary">User Panel</a>
        </div>
    </div>
    <br>
    <div class="row1">
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('login/taskdetails');?>" class="btn btn-secondary">Task Details</a>
        </div>
    </div>
    <br>
    <div class="row1">
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('login/notification');?>" class="btn btn-secondary">Notification</a>
        </div>
    </div>
    <br>
    <div class="row1">
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('login/request');?>" class="btn btn-secondary">Requests</a>
        </div>
    </div>
    <br>
    <div class="row1">
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('login/designation');?>" class="btn btn-secondary">Designation</a>
        </div>
    </div>
</div>
<div class="container">
    <h2><img src=<?php echo base_url("uploads/".$result->image); ?> width=70 height="50">  Profile</h2>
   <table class="table">
        <tbody>
            <tr>
                <td>Username:</td>
                <td><?php echo $result->username; ?></td>
            </tr>
            <tr>
                <td>Name:</td>
                <td><?php echo $result->name; ?></td>
            </tr>
            <tr>
                <td>Email:</td>
                <td><?php echo $result->email; ?></td>
            </tr>
            <tr>
                <td>Password:</td>
                <td><?php echo $result->password; ?></td>
            </tr>
            <tr>
                <td>
                    <?php echo anchor("login/editprofile/{$result->id}",'Edit',['class'=>"btn btn-primary",'id'=>'btn1']); ?>
                </td>
            </tr>       
        </tbody>
    </table>
</div>
<?php include('admin_footer.php'); ?>  