<?php include('admin_header.php'); ?>
<style>
    .container{margin-left:10px;
        float: right;
        height: 100%;
        width:1050px;
    }
    .shift{
        margin-left: 290px;
    }
</style>
<style>
    #main{
        
        width:21%;
        background:gray;
        float: left;
        height: 1123px;
        text-align: center;
    }
    #h6{
        font-size: 17px;
    }
    .row1{
        background: orange;
        width:100;
        color: white;
    }
    .btn{
        width:100%;
    }
    #id{
        float:left;
        width:80px;
    }
    label,th,td{
        color:whitesmoke;
    }
    
</style>
 <div id="main">

   
   
    <h6 id="h6"><img src=<?php echo base_url("uploads/".$result2->image); ?> width=70 height="50"><?php echo "&nbspWelcome&nbsp".$result2->username; ?></h6>
    <div class="row1">
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('profile');?>" class="btn btn-secondary">Profile</a>
        </div>
    </div>
    <br>
    <div class="row1" >
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('login/userpanel');?>" class="btn btn-secondary">User Panel</a>
        </div>
    </div>
    <br>
    <div class="row1">
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('login/taskdetails');?>" class="btn btn-secondary">Task Details</a>
        </div>
    </div>
    <br>
    <div class="row1">
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('login/notification');?>" class="btn btn-secondary">Notification</a>
        </div>
    </div>
    <br>
    <div class="row1">
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('login/request');?>" class="btn btn-secondary">Requests</a>
        </div>
    </div>
    <br>
    <div class="row1">
        <div class="col-lg-6 col-lg-offset-6">
            <a href="<?php echo base_url('login/designation');?>" class="btn btn-secondary">Designation</a>
        </div>
    </div>
</div>

<div class="container">
    
    <?php echo form_open(base_url('login/updatenotification'), ['class' => 'form-horizontal']) ?>
    <?php echo form_hidden('user_id', $this->session->userdata('user_id')) ?>
    <?php echo form_hidden('notification_id', $result->id) ?>
    <fieldset>
        <legend>Add Notification</legend>

        <div class="row">
            <div class="col-lg-6">
                <div class="form-group">
                    <label for="exampleInputEmail1">Notification Title</label>
                    <?php echo form_input(['name' => 'title', 'value' => set_value('title',$result->title), 'type' => 'text', 'class' => 'form-control', 'placeholder' => 'Enter Notification Title Here']); ?>
                    <!-- <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email"> -->
                    <?php
                    if (!empty($error['title'])) {
                        echo $error['title'];
                    }
                    ?>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-6">
                <div class="form-group">
                    <label for="exampleInputPassword1">Description</label>
                    <?php echo form_textarea(['name' => 'body', 'class' => 'form-control', 'id' => 'exampleInputPassword1', 'value' => set_value('body',$result->body), 'placeholder' => 'Enter Notification Here']); ?>
                   
                    <?php
                    if (!empty($error['body'])) {
                        echo $error['body'];
                    }
                    ?>
                </div>
            </div>
        </div>   
        <?php echo form_submit(['name' => 'Submit', 'value' => 'Save Changes', 'class' => 'btn1 btn-primary']); ?>
       
        </form>
    </fieldset>
</div>

<?php include('admin_footer.php'); ?>
