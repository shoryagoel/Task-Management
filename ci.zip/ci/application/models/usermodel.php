<?php 
    class Usermodel extends CI_Model{
        public function dashboard() {
            $employee_id = $this->session->userdata('employee_id');
            $q = $this->db->where('employee_id',$employee_id)
                          ->get('employee');
            return $q->row();
        }
        public function get_profile(){
            $employee_id = $this->session->userdata('employee_id');
            $q = $this->db->query("Select employee_id,e.name as name,gender,d.name as designation,dob,city,permanent_address,temporary_address,email
                    from employee e,designation d where e.employee_id = $employee_id and e.designation = d.id");
            return $q->row();
        }
        public function get_taskdetails() {
            $employee_id = $this->session->userdata('employee_id');
            $q = $this->db->query("select id,title,description,priority,e.name as assigned_by,progress,date from task t,employee e where
                t.assigned_by = e.employee_id    and   assigned_to = $employee_id and t.progress='In Progress' ");
            return $q->result();
        }
        
        public function get_notification() {
            $q = $this->db->get('notification');
            return $q->result();
        }
        
        public function get_list() {
            $q = $this->db->select(['name','employee_id','email'])
                      ->get('employee');
            return $q->result();
        }
        public function assign_task() {
            $employee_id = $this->session->userdata('employee_id');
            $data = [
                'title' => $this->input->post('title'),
                'description' => $this->input->post('description'),
                'assigned_to' => $this->input->post('assigned_to'),
                'priority' => $this->input->post('priority'),
                'assigned_by' => $employee_id
            ];
            
            $q = $this->db->where('assigned_by',$employee_id)
                          ->insert('task',$data);
                  return $this->db->insert_id();
        }
        public function assigned_task() {
             $employee_id = $this->session->userdata('employee_id');
             $q = $this->db->query("Select title,description,e.name as assigned_to,priority,progress,date from task t,employee e where
                t.assigned_by = $employee_id and assigned_to = employee_id");
             return $q->result();
        }
        
        public function sendrequest() {
            $employee_id = $this->session->userdata('employee_id');
            $data = [
                'subject' => $this->input->post('subject'),
                'description' => $this->input->post('description'),
                'to' => $this->input->post('to'),
                'by' => $employee_id
            ];
            $this->db->insert('request',$data);
            return $this->db->insert_id();
        }
         public function get_admin() {
            $q = $this->db->select(['name','id'])
                      ->get('admin');
            return $q->result();
        }
        public function get_request() {
            $employee_id = $this->session->userdata('employee_id');
                $q = $this->db->query("select subject,description,a.name as name,date from request r,admin a
                          where r.by = $employee_id and r.to = a.id");
            return $q->result();
        }
        public function task_description($id) {
            $emp = $this->session->userdata('employee_id');
         $q = $this->db->select('id,title,description,progress')
                       ->where(['id'=>$id,'assigned_to'=>$emp])
                       ->get('task');
         return $q->row();
        }
        public function save_progress($id) {
            $progress  = $this->input->post('progress');
            $this->db->update('task',['progress'=>$progress],['id'=>$id]);
            return $this->db->affected_rows();
        }
        public function completed_task() {
            $employee_id = $this->session->userdata('employee_id');
            $q = $this->db->query("select id,title,description,priority,e.name as assigned_by,progress,date from task t,employee e where
                t.assigned_by = e.employee_id    and   assigned_to = $employee_id and t.progress='Completed' ");
            return $q->result();
        }
    }
?>
