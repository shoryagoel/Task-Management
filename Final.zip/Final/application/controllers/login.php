<?php

class Login extends MY_Controller {

    public function index() {
        if(!empty($this->session->userdata('error'))){
            $error = $this->session->userdata('error');
            $this->session->unset_userdata('error');
        }
        if(!empty($this->session->userdata('login_failed'))){
            $error['login_failed'] = $this->session->userdata('login_failed');
            $this->session->unset_userdata('login_failed');
        }else{
            $error['login_failed']="";
        }
        $this->load->view('public/admin_login',['error'=>$error]);
    }

    public function admin_login() {
        $this->load->library('form_validation');
        $this->form_validation->set_rules('username', 'User Name', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');
//        $this->form_validation->set_error_delimiters("<p class='text-danger'>", "</p>");
        if ($this->form_validation->run() === FALSE) {
            $error = $this->form_validation->error_array();
            $this->session->set_userdata('error', $error);
            redirect(base_url('login'));
        } else {
            $username = $this->input->post('username');
            $password = $this->input->post('password');
            $this->load->model('loginmodel');
            $login_id = $this->loginmodel->login_valid($username, $password);
            if ($login_id){
                $log = $this->session->userdata('log');
                if($log=='admin'){
                    $this->session->set_userdata('user_id', $login_id);
                    return redirect('login/dashboard');
                }if($log=='employee'){
                    $this->session->set_userdata('employee_id', $login_id);
                    return redirect('user/dashboard');
                }
            }else {
                $this->session->set_userdata('login_failed', 'Invalid Username/Password.');
                return redirect('login');
            }
        }
    }
public function dashboard() {
    if(!empty($this->session->userdata('status'))){
        $status = $this->session->userdata('status');
        $this->session->unset_userdata('status');
    } else {
        $status="";
    }
    $this->load->model('loginmodel');
    $result = $this->loginmodel->dashboard();
    $this->load->view('admin/dashboard',['result'=>$result,'status'=>$status]);
    }
    
    public function userpanel() {
        if(!empty($this->session->userdata('delete'))){
            $delete = $this->session->userdata('delete');
            $this->session->unset_userdata('delete');
        }else{
            $delete="";
        }
        if(!empty($this->session->userdata('edit'))){
            $edit = $this->session->userdata('edit');
            $this->session->unset_userdata('edit');
        }else{
            $edit="";
        }
        if(!empty($this->session->userdata('block'))){
            $block = $this->session->userdata('block');
            $this->session->unset_userdata('block');
        }else{
            $block="";
        }
    $this->load->model('loginmodel');
    $result = $this->loginmodel->users();
    $result2 = $this->loginmodel->dashboard();
    if(!empty($this->session->userdata('status'))){
         $status['status'] = $this->session->userdata('status');
         $this->session->unset_userdata('status');
        }else{
            $status['status'] = "";
        }
    $this->load->view('admin/users',['result'=>$result,'block'=>$block,'edit'=>$edit,'result2'=>$result2,'status'=>$status,'delete'=>$delete]);
    }
    
    public function adduser() {
        if(!empty($this->session->userdata('error'))){
            $error = $this->session->userdata('error');
            $this->session->unset_userdata('error');
        }else{
            $error = "";
        }
        $this->load->model('loginmodel');
        $result2 = $this->loginmodel->dashboard();
        $result  = $this->loginmodel->get_designation();
//        print_r($result);die;
        $this->load->view('admin/add_user',['error'=>$error,'result2'=>$result2,'result'=>$result]);
    }
    public function do_adduser(){
        $this->load->library('form_validation');
        $this->form_validation->set_rules('name','Username','required');
        $this->form_validation->set_rules('gender','Gender','required');
        $this->form_validation->set_rules('designation','Designation','required');
        $this->form_validation->set_rules('dob','DOB','required');
        $this->form_validation->set_rules('city','City','required|alpha');
        $this->form_validation->set_rules('permanent_address','Permanent Address','required|max_length[50]');
        $this->form_validation->set_rules('temporary_address','Temporary Address','required|max_length[50]');
        $this->form_validation->set_rules('email','Email Id','required');
        $this->form_validation->set_rules('password','Password','required');
        if($this->form_validation->run()){
            $this->load->model('loginmodel');
            $result = $this->loginmodel->add_user();
            if($result){
                $this->session->set_userdata('status','User Added Successfully...');
                redirect('login/userpanel');
            }else{
            $this->session->set_userdata('status','Unable To Add User...');
            redirect('login/userpanel');    
            }
        }else{
            $error = $this->form_validation->error_array();
            $this->session->set_userdata(error,$error);
            redirect('login/adduser');
            
        } 
    }

    public function taskdetails() {
        $this->load->model('loginmodel');
        $result2 = $this->loginmodel->dashboard();
        $result = $this->loginmodel->get_task_details();
        $this->load->view('admin/task_details',['result'=>$result,'result2'=>$result2]);
    }
    
    public function logout() {
        $this->session->unset_userdata('user_id');
        return redirect('login');
    }
    public function editprofile($id) {
        
        $this->load->model('loginmodel');
        $result2 = $this->loginmodel->dashboard();
        if(!empty($this->session->userdata('upload_error'))){
            $upload_error = $this->session->userdata('upload_error');
            $this->session->unset_userdata('upload_error');
        }
        else{
            $upload_error = "";
        }
        if(!empty($this->session->userdata('error'))){
            $error = $this->session->userdata('error');
            
            $this->session->unset_userdata('error');
        }
        else{
            $error = "";
        }
        $result = $this->loginmodel->edit_profile($id);
        $this->load->view('admin/edit_profile',['result'=>$result,'result2'=>$result2,'error'=>$error,'upload_error'=>$upload_error]);
    }
    public function updateprofile(){
        $id = $this->input->post('id');
        $this->load->library('form_validation');
        $this->form_validation->set_rules('username','Username','required');
        $this->form_validation->set_rules('name','Name','required');
        $this->form_validation->set_rules('email','Email','required');
        $this->form_validation->set_rules('password','Password','required');
    $config = [
        'upload_path' => './uploads',
        'allowed_types' => 'jpeg|png|jpg|gif'
    ];
        $file = $_FILES['userfile']['name'];
        $this->load->library('upload',$config);
        if($this->form_validation->run()){
            $data = [
                'username' => $this->input->post('username'),
                'name' => $this->input->post('name'),
                'password' => $this->input->post('password'),
                
            ];
            $this->upload->do_upload('userfile');
            $this->load->model('loginmodel');
            $result = $this->loginmodel->update_profile($id,$data,$file);
            if($result){
                $this->session->set_userdata('status','Profile updated successfully...');
                redirect('login/dashboard');
            }else{
                $this->session->set_userdata('status','Profile update failed...');
                redirect('login/dashboard');
            }
        }else{
            $error = $this->form_validation->error_array();
            $upload_error =  $this->upload->display_errors();
            $this->session->set_userdata('error',$error);
            $this->session->set_userdata('upload_error',$upload_error); 
            redirect('login/editprofile/'.$id);
        }
    }
    public function deleteuser(){
        $employee_id = $this->input->post('employee_id');
        $this->load->model('loginmodel');
        $q = $this->loginmodel->delete_user($employee_id);
        if($q){
            $this->session->set_userdata('delete',"user deleted successfully...");
            redirect('login/userpanel');
        }else{
            $this->session->set_userdata('delete',"Failed to delete user...");
            redirect('login/userpanel');
        }
    }
    public function edituser($employee_id){
        if(!empty($this->session->userdata('error'))){
            $error = $this->session->userdata('error');
            $this->session->unset_userdata('error');
        }else{
            $error="";
        }
        
        $this->load->model('loginmodel');
        $result = $this->loginmodel->edit_user($employee_id);
        $desig  = $this->loginmodel->edit_user_designation();
        $result2 = $this->loginmodel->dashboard();
        $this->load->view('admin/edit_user',['error'=>$error,'result2'=>$result2,'result'=>$result,'desig'=>$desig]);
    }

    public function do_edituser() {
        $employee_id = $this->input->post('employee_id');
        $this->load->library('form_validation');
        $this->form_validation->set_rules('name','Username','required');
        $this->form_validation->set_rules('gender','Gender','required');
        $this->form_validation->set_rules('designation','Designation','required');
        $this->form_validation->set_rules('dob','DOB','required');
        $this->form_validation->set_rules('city','City','required|alpha');
        $this->form_validation->set_rules('permanent_address','Permanent Address','required|max_length[50]');
        $this->form_validation->set_rules('temporary_address','Temporary Address','required|max_length[50]');
        $this->form_validation->set_rules('email','Email Id','required');
        $this->form_validation->set_rules('password','Password','required');
        if($this->form_validation->run()){
            $this->load->model('loginmodel');
            $result = $this->loginmodel->update_user($employee_id);
            if($result){
                $this->session->set_userdata('edit','User Profile Updated Successfully...');
                redirect('login/userpanel');
            }else{
            $this->session->set_userdata('edit','Unable to update user profile...');
            redirect('login/userpanel');    
            }
        }else{
            $error = $this->form_validation->error_array();
            $this->session->set_userdata('error',$error);
            redirect('login/edituser/'.$employee_id);
            
        } 
    }
     public function notification() {
        if(!empty($this->session->userdata('error')) || !empty($this->session->userdata('success')) || !empty($this->session->userdata('status'))){
            $error = $this->session->userdata('error');
            $success = $this->session->userdata('success');
            $this->session->unset_userdata('success');
            $this->session->unset_userdata('error');
            $status = $this->session->userdata('status');
            $this->session->unset_userdata('status');
        }
        else{
            $status="";
            $success="";
            $error="";
        }
        $this->load->model('loginmodel');
        $result = $this->loginmodel->get_notification();
        $result2 = $this->loginmodel->dashboard();
        $this->load->view('admin/notification',['result'=>$result,'status'=>$status,'result2'=>$result2,'success'=>$success,'error'=>$error]);
        
    }
    public function add_notification() {
        if(!empty($this->session->userdata('error'))){
            $error = $this->session->userdata('error');
            $this->session->unset_userdata('error');
        }
        else{
            
            $error="";
        }
        $this->load->model('loginmodel');
        $result2 = $this->loginmodel->dashboard();
        $this->load->view('admin/add_notification',['result2'=>$result2,'error'=>$error]);
        
    }
    public function do_notification() {
        
        $this->load->model('loginmodel');
        $this->form_validation->set_rules('title', 'Title', 'required');
        $this->form_validation->set_rules('body', 'Description', 'required');
        if ($this->form_validation->run()===FALSE) {
            $error = $this->form_validation->error_array();
            $this->session->set_userdata('error', $error);
            redirect(base_url('login/add_notification'));
        } else {
          
            $result = $this->loginmodel->do_add_notification();
            if ($result) {
                $success = 'Notification Added Successfully...';
                $this->session->set_userdata('success',$success);
                redirect(base_url('login/notification'));
            } else {
                $success =  'Failed To Add Notification, Please Try Again.';
                $this->session->set_userdata('success',$success);
                redirect(base_url('login/notification'));
            }
        }
    }
    public function deletenotification() {
        $notification_id = $this->input->post('notification_id');
        $this->load->model('loginmodel');
        $q = $this->loginmodel->delete_notification($notification_id);
        if($q){
            $this->session->set_userdata('status','Deleted Successfully...');
            redirect('login/notification');
        }else{
            $this->session->set_userdata('status','Unable To Delete...');
            redirect('login/notification');
        }
    }
    
    public function editnotification($id) {
        if(!empty($this->session->userdata('error')) || !empty($this->session->userdata('success')) || !empty($this->session->userdata('status'))){
            $error = $this->session->userdata('error');
            $success = $this->session->userdata('success');
            $this->session->unset_userdata('success');
            $this->session->unset_userdata('error');
            $status = $this->session->userdata('status');
            $this->session->unset_userdata('status');
        }
        else{
            $status="";
            $success="";
            $error="";
        }
        $this->load->model('loginmodel');
        $result = $this->loginmodel->edit_notification($id);
        $result2 = $this->loginmodel->dashboard();
        $this->load->view('admin/edit_notification',['result'=>$result,'status'=>$status,'result2'=>$result2,'success'=>$success,'error'=>$error]);
    }
    
    public function updatenotification() {
        $id = $this->input->post('notification_id');
        $this->load->model('loginmodel');
        $this->form_validation->set_rules('title', 'Title', 'required');
        $this->form_validation->set_rules('body', 'Description', 'required');
        if ($this->form_validation->run()===FALSE) {
            $error = $this->form_validation->error_array();
            $this->session->set_userdata('error', $error);
            redirect(base_url('login/editnotification/'.$id));
        } else {
          
            $result = $this->loginmodel->do_update_notification($id);
            if ($result) {
                $success = 'Notification updated Successfully...';
                $this->session->set_userdata('success',$success);
                redirect(base_url('login/notification'));
            } else {
                $success =  'Failed To Update Notification, Please Try Again.';
                $this->session->set_userdata('success',$success);
                redirect(base_url('login/editnotification/'.$id));
            }
        }
    }
    public function request() {
        $this->load->model('loginmodel');
        $result2 = $this->loginmodel->dashboard();
        $result = $this->loginmodel->request();
        $this->load->view('admin/request',['result2'=>$result2,'result'=>$result]);
    }
    public function block($employee_id,$block) {
        $this->load->model('loginmodel');
        $q = $this->loginmodel->block($employee_id,$block);
        if($q){
            $this->session->set_userdata('block','Action Performed successfully...');
            redirect('login/userpanel');
        }
        else{
            $this->session->set_userdata('block','Action Failed!!!');
            redirect('login/userpanel');
        }
    }
    
    public function designation() {
        if(!empty($this->session->userdata('edit')) || !empty($this->session->userdata('status'))){
            $edit = $this->session->userdata('edit');
            $status = $this->session->userdata('status');
            $this->session->unset_userdata('status');
            $this->session->unset_userdata('edit');
        }else{
            $edit="";
            $status="";
        }
        $this->load->model('loginmodel');
        $result = $this->loginmodel->designation();
       
        $result2 = $this->loginmodel->dashboard();
        $this->load->view('admin\designation.php',['result'=>$result,'result2'=>$result2,'edit'=>$edit,'status'=>$status]);
    }
    
    public function do_designation() {
        if(!empty($this->session->userdata('error'))){
            $error = $this->session->userdata('error');
            $this->session->unset_userdata('error');
        }else{
            $error="";
        }
         $this->load->model('loginmodel');
        $result2 = $this->loginmodel->dashboard();
        $this->load->view('admin\add_designation.php',['result2'=>$result2,'error'=>$error]);
    }
    
    public function add_designation() {
        $this->load->library('form_validation');
        $this->form_validation->set_rules('name','Designation Name','required|is_unique[designation.name]');
         $this->load->model('loginmodel');
         if($this->form_validation->run()==TRUE){
            $result = $this->loginmodel->add_designation();
            if($result){
                $this->session->set_userdata('edit','User Profile Updated Successfully...');
                redirect('login/designation');
            }else{
            $this->session->set_userdata('edit','Unable to update user profile...');
            redirect('login/designation');    
            }
        }else{
            $error = $this->form_validation->error_array();
            $this->session->set_userdata('error',$error);
            redirect('login/do_designation');    
        } 
    }
    
    public function edit_desig($id) {
        if(!empty($this->session->userdata('error'))){
            $error = $this->session->userdata('error');
            $this->session->unset_userdata('error');
        }else{
           
            $error="";
        }
      $this->load->model('loginmodel');
      $result2 = $this->loginmodel->dashboard();
      $result = $this->loginmodel->get_edit_desig($id);
      $this->load->view('admin/edit_designation',['result2'=>$result2,'result'=>$result,'error'=>$error]);
    }
    public function do_edit_desig(){
         $this->load->library('form_validation');
         $this->form_validation->set_rules('name','Designation Name','required');
         $this->load->model('loginmodel');
         $id = $this->input->post('id');
        if($this->form_validation->run()==TRUE){
            
            $result = $this->loginmodel->update_desig($id);
            if($result){
                $this->session->set_userdata('edit','Designation Updated Successfully...');
                redirect('login/designation');
            }else{
            $this->session->set_userdata('edit','Unable to update Designation...');
            redirect('login/designation');    
            }
        }else{
            $error = $this->form_validation->error_array();
            $this->session->set_userdata('error',$error);
            redirect('login/edit_desig/'.$id);    
        } 
    }
    public function delete_desig($id) {
        $this->load->model('loginmodel');
        $q = $this->loginmodel->delete_designation($id);
        if($q){
            $this->session->set_userdata('status','Designation deleted Successfully...');
            redirect('login/designation');
        }else{
            $this->session->set_userdata('status','Unable To Delete Designation...');
            redirect('login/designation');
        }
    }
}

?>