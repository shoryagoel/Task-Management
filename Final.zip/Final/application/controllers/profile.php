<?php
class Profile extends CI_Controller{
    public function index() {
        $this->load->model('loginmodel');
        $result = $this->loginmodel->profile_load();
        $result2 = $this->loginmodel->dashboard();
        $this->load->view('admin/profile_view',['result'=>$result,'result2'=>$result2]);
    }   
}
?>

