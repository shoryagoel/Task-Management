<?php 
    class User extends CI_Controller{
        
        public function dashboard() {
            $this->load->model('usermodel');
            $result = $this->usermodel->dashboard();
            $this->load->view('public/dashboard',['result'=>$result]);
        }
        
        public function profile() {
            $this->load->model('usermodel');
            $result = $this->usermodel->get_profile();
            
            $this->load->view('public/user_profile',['result'=>$result]);
        }
        
        public function logout(){
             $this->session->unset_userdata('user_id');
            return redirect('login');   
        }
        public function taskdetails() {
            if(!empty($this->session->userdata('status'))){
                $status = $this->session->userdata('status');
                $this->session->unset_userdata('status');
            }else{
                $status="";
            }
            $this->load->model('usermodel');
            $result2 = $this->usermodel->dashboard();
            $result=$this->usermodel->get_taskdetails();
            $this->load->view('public/user_taskdetails',['result'=>$result,'result2'=>$result2,'status'=>$status]);
        }
        public function notification() {
            $this->load->model('usermodel');
            $result2 = $this->usermodel->dashboard();
            $result=$this->usermodel->get_notification();
            $this->load->view('public/user_notification',['result'=>$result,'result2'=>$result2]);
        }
        public function assigntask() {
            if(!empty($this->session->userdata('error'))){
                $error = $this->session->userdata('error');
                $this->session->unset_userdata('error');
            }else{
                $error="";
            }
            $this->load->model('usermodel');
            $result2 = $this->usermodel->dashboard();
            $result = $this->usermodel->get_list();
            $this->load->view('public/assign_task',['result2'=>$result2,'result'=>$result,'error'=>$error]);
        }
        
        public function do_assigntask() {
            
            $this->load->model('usermodel');
            $result2 = $this->usermodel->dashboard();
            $this->form_validation->set_rules('title','Task Title','required');
            $this->form_validation->set_rules('description','Description','required');
            $this->form_validation->set_rules('assigned_to','Assigned To','required');
            $this->form_validation->set_rules('priority','Priority','required');
            if($this->form_validation->run()==TRUE){
               
                $q = $this->usermodel->assign_task();
                if($q){
                    $this->session->set_userdata('status','Task Assigned successfully...');
                    redirect('user/assigned_task');
                }
                else{
                    $this->session->set_userdata('status','Unable To Assign Task...');
                    redirect('user/assigned_task');
                }
            }
            else{
            $error = $this->form_validation->error_array();
            $this->session->set_userdata('error',$error);
            redirect('user/assigntask');
            }   
        }
        
        public function assigned_task(){
            $this->load->model('usermodel');
            $result2 = $this->usermodel->dashboard();
            $result = $this->usermodel->assigned_task();
            $this->load->view('public/assigned_task',['result2'=>$result2,'result'=>$result]);
        }
        public function request_send() {
            
            $this->load->model('usermodel');
            $result2 = $this->usermodel->dashboard();
            $result = $this->usermodel->get_request();
            $this->load->view('public/requestshow',['result'=>$result,'result2'=>$result2]);
        }
        public function request() {
            if(!empty($this->session->userdata('error')) || !empty($this->session->userdata('status'))){
                $error = $this->session->userdata('error');
                $status = $this->session->userdata('status');
                $this->session->unset_userdata('status');
                $this->session->unset_userdata('error');
            }else{
                $error="";
                $status = "";
            }
            $this->load->model('usermodel');
            $result2 = $this->usermodel->dashboard();
            $result = $this->usermodel->get_admin();
            $this->load->view('public/request',['result2'=>$result2,'result'=>$result,'error'=>$error,'status'=>$status]);
        }
        public function sendrequest(){
            $this->load->model('usermodel');
            $this->form_validation->set_rules('subject','Subject','required');
            $this->form_validation->set_rules('description','Description','required');
            $this->form_validation->set_rules('to','Sent To','required');
            if($this->form_validation->run()==TRUE){
               
                $q = $this->usermodel->sendrequest();
                if($q){
                    $this->session->set_userdata('status','Request Sent successfully...');
                    redirect('user/request_send');
                }
                else{
                    $this->session->set_userdata('status','Unable To Sent Request...');
                    redirect('user/request_send');
                }
            }
            else{
            $error = $this->form_validation->error_array();
            $this->session->set_userdata('error',$error);
            redirect('user/request');
            }   
        }
        public function task_description($id) {
            if(!empty($this->session->userdata('error'))){
                $error = $this->session->userdata('error');
                $this->session->unset_userdata('error');
            }else{
                $error="";
            }
            $this->load->model('usermodel');
            $result2 = $this->usermodel->dashboard();
            $result = $this->usermodel->task_description($id);
            $this->load->view('public/task_description',['result2'=>$result2,'result'=>$result,'error'=>$error]); 
        }
        
        public function save_progress($id) {
             $this->load->model('usermodel');
            $this->form_validation->set_rules('progress','Progress','required');
            if($this->form_validation->run()==TRUE){
               
                $q = $this->usermodel->save_progress($id);
                if($q){
//                    $this->session->set_userdata('status','Request Sent successfully...');
                    redirect('user/taskdetails');
                }
                else{
//                    $this->session->set_userdata('status','Unable To Sent Request...');
                    redirect('user/taskdetails');
                }
            }
            else{
            $error = $this->form_validation->error_array();
            $this->session->set_userdata('error',$error);
            redirect('user/task_description/'.$id);
            }   
        }
        public function completed_task() {
             $this->load->model('usermodel');
            $result2 = $this->usermodel->dashboard();
            $result = $this->usermodel->completed_task();
            $this->load->view('public/completed_task',['result2'=>$result2,'result'=>$result]); 
        }
    }

?>