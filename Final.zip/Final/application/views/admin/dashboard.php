 <?php include('admin_header.php'); ?> 
<style>
    #main{
        height: 100vh;
        width:22%;
        background:#263544;
        float: left;
        /*text-align: center;*/
    }
    #h6{
        font-size: 17px;
    }
    .row_lst{     
        color: white;
    }
    #btn1:hover{
        transform: scale(1.1);
    transition: all 0.35s ease;
    border:1px solid #263544;
    }
    .btn{
        width:100%;
    }
    .list_btn a{
        color: #fff;
        font-size: 15px;
        border: none;
    }
    .list_btn a:hover{
      transform: scale(1.1);
      transition: all 0.35s ease;
    }
    label,th,td{
        color:whitesmoke;
    }
    .img_box{
        height: 80px;
        width: 80px;
        border-radius: 50%;
            display: inline-block;
    }
    #main img.logo_img{
        width: 100%;
        height: 100%;
        border-radius: 50%;
    }
    .log_div{
        padding: 10px 0px;
    }
    .log_div h6{
        display: inline-block;
        font-size: 16px;
        color: #ffffff;
    }
    .list_btn{
        width: 100%;
        display: inline-block;
    }
    .btn_clr{
        background-image: linear-gradient(to right bottom, #053730, #406469, #80949e, #c2c7cf, #ffffff);
    }
    .list_btn a{
        color: #fff;
        font-size: 15px;
        border: none;
    }
    .list_btn a:hover{
      transform: scale(1.1);
      transition: all 0.35s ease;
    }
    .btn_clr i{
        margin-right: 10px;
    }
    .bg_image{
     width: 78%;
    float: right;
    }
    .bg_image img{
            width: 100%;
    height: 100vh;
    }
</style>
 <div id="main">
<div class="container">
   
    <?php if(!empty($status)){echo $status;} ?>
    <div class="log_div">
        <div class="img_box">
            <img src="<?php echo base_url("uploads/".$result->image); ?>" class="img-responsive logo_img" alt="image">
        </div>
        
    <h6><?php echo "&nbspWelcome&nbsp".$result->username; ?></h6>
    </div>
    
<!--    <h6 id="h6"><img src=<?php echo base_url("uploads/".$result->image); ?> width=70 height="50"><?php echo "&nbspWelcome&nbsp".$result->username; ?></h6>-->
    <div class="row_lst">
        <div class="list_btn">
            
            <a href="<?php echo base_url('profile');?>" class="btn btn-secondary btn_clr"><i class="fa fa-user-plus" aria-hidden="true"></i><span>Profile</span></a>
        </div>
    </div>
    <br>
    <div class="row_lst">
        <div class="list_btn">
            <a href="<?php echo base_url('login/userpanel');?>" class="btn btn-secondary btn_clr"><i class="fa fa-address-book"></i><span>User Panel</span></a>
        </div>
    </div>
    <br>
    <div class="row_lst">
        <div class="list_btn">
            <a href="<?php echo base_url('login/taskdetails');?>" class="btn btn-secondary btn_clr"><i class="fa fa-tasks"></i><span>Task Details</span></a>
        </div>
    </div>
    <br>
    <div class="row_lst">
        <div class="list_btn">
            <a href="<?php echo base_url('login/notification');?>" class="btn btn-secondary btn_clr"><i class="fa fa-bell"></i><span>Notification</span></a>
        </div>
    </div>
    <br>
    <div class="row_lst">
        <div class="list_btn">
            <a href="<?php echo base_url('login/request');?>" class="btn btn-secondary btn_clr"><i class="fa fa-users"></i><span>Requests</span></a>
        </div>
    </div>
    <br>
    <div class="row_lst">
        <div class="list_btn">
            <a href="<?php echo base_url('login/designation');?>" class="btn btn-secondary btn_clr"><i class="fa fa-user"></i><span>Designation</span></a>
        </div>
    </div>
</div>
</div>
<div class="bg_image">
    <img src="<?php echo base_url("uploads/".'img.png'); ?>" class="img-responsive" alt="image">
</div>
<?php include('admin_footer.php'); ?>  