 <?php include('admin_header.php'); ?> 
<style>
    #main{
        height: 100vh;
        width:22%;
        background:#263544;
        float: left;
        /*text-align: center;*/
    }
    #h6{
        font-size: 17px;
    }
    .list_btn a{
        color: #fff;
        font-size: 15px;
        border: none;
    }
    .list_btn a:hover{
      transform: scale(1.1);
      transition: all 0.35s ease;
    }
    .row_lst{
      
        color: white;
      
    }
    .btn{
        width:100%;
    }
    label,th,td{
        color:whitesmoke;
    }
    .img_box{
        height: 80px;
        width: 80px;
        border-radius: 50%;
            display: inline-block;
    }
    #main img.logo_img{
        width: 100%;
        height: 100%;
        border-radius: 50%;
    }
    .log_div{
        padding: 10px 0px;
    }
    .log_div h6{
        display: inline-block;
        font-size: 16px;
        color: #ffffff;
    }
    .list_btn{
        width: 100%;
        display: inline-block;
    }
    .btn_clr{
        background-image: linear-gradient(to right bottom, #053730, #406469, #80949e, #c2c7cf, #ffffff);
    }
    .btn_clr i{
        margin-right: 10px;
    }
     .l_color{
        color: black;
    }
          
     .form_bg{
 width: 78%;
 display: flex;
 justify-content: center;
 float: right;
 
height: 100vh;
 background: rgba(182,215,237,1);
padding: 20px 0px;
 align-items: center;
    }
    .show_box{
        background-color: #fff;
    width: 500px;
    border-radius: 4px;
    margin: 0 auto;
    padding: 30px 30px;
    box-shadow: 0 2px 4px 0 rgba(0,0,0,0.4);
    }
    .show_box h2{
        color: #000;
        text-align: center;
        font-size: 30px;
    }
    .table tr td{
        border-top: none; 
    }
    .td_sec{
    border: 2px solid #ddd;
    border-radius: 5px;
    display: block;
    margin-bottom: 15px;
    }
    #btn1{
      background: rgba(182,215,237,1);  
    }
</style>
 <div id="main">
<div class="container">
   
    <?php if(!empty($status)){echo $status;} ?>
    <div class="log_div">
        <div class="img_box">
            <img src="<?php echo base_url("uploads/".$result2->image); ?>" class="img-responsive logo_img" alt="image">
        </div>
        
    <h6><?php echo "&nbspWelcome&nbsp".$result2->username; ?></h6>
    </div>
    
<!--    <h6 id="h6"><img src=<?php echo base_url("uploads/".$result->image); ?> width=70 height="50"><?php echo "&nbspWelcome&nbsp".$result->username; ?></h6>-->
    <div class="row_lst">
        <div class="list_btn">
            
            <a href="<?php echo base_url('profile');?>" class="btn btn-secondary btn_clr"><i class="fa fa-user-plus" aria-hidden="true"></i><span>Profile</span></a>
        </div>
    </div>
    <br>
    <div class="row_lst">
        <div class="list_btn">
            <a href="<?php echo base_url('login/userpanel');?>" class="btn btn-secondary btn_clr"><i class="fa fa-address-book"></i><span>User Panel</span></a>
        </div>
    </div>
    <br>
    <div class="row_lst">
        <div class="list_btn">
            <a href="<?php echo base_url('login/taskdetails');?>" class="btn btn-secondary btn_clr"><i class="fa fa-tasks"></i><span>Task Details</span></a>
        </div>
    </div>
    <br>
    <div class="row_lst">
        <div class="list_btn">
            <a href="<?php echo base_url('login/notification');?>" class="btn btn-secondary btn_clr"><i class="fa fa-bell"></i><span>Notification</span></a>
        </div>
    </div>
    <br>
    <div class="row_lst">
        <div class="list_btn">
            <a href="<?php echo base_url('login/request');?>" class="btn btn-secondary btn_clr"><i class="fa fa-users"></i><span>Requests</span></a>
        </div>
    </div>
    <br>
    <div class="row_lst">
        <div class="list_btn">
            <a href="<?php echo base_url('login/designation');?>" class="btn btn-secondary btn_clr"><i class="fa fa-user"></i><span>Designation</span></a>
        </div>
    </div>
</div>
</div>
<div class="form_bg">
<div class="container">
    <div class="show_box">
    <?php echo form_open(base_url('login/do_notification'), ['class' => 'form-horizontal']) ?>
    <?php echo form_hidden('user_id', $this->session->userdata('user_id')) ?>
    
    <fieldset>
        <legend class="l_color">Add Notification</legend>

        <div class="row">
            <div class="col-lg-12">
                <div class="form-group">
                    <label for="exampleInputEmail1" class="l_color">Notification Title</label>
                    <?php echo form_input(['name' => 'title', 'value' => set_value('title'), 'type' => 'text', 'class' => 'td_sec form-control', 'placeholder' => 'Enter Notification Title Here']); ?>
                    <!-- <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email"> -->
                    <?php
                    if (!empty($error['title'])) {
                        echo $error['title'];
                    }
                    ?>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-12">
                <div class="form-group">
                    <label for="exampleInputPassword1" class="l_color">Description</label>
                    <?php echo form_textarea(['name' => 'body', 'class' => 'td_sec form-control', 'id' => 'exampleInputPassword1', 'value' => set_value('body'), 'placeholder' => 'Enter Notification Here']); ?>
                    <!-- <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password"> -->
                    <?php
                    if (!empty($error['body'])) {
                        echo $error['body'];
                    }
                    ?>
                </div>
            </div>
        </div>
<!--        <div class="row">
            <div class="col-lg-6">
                <div class="form-group">
                    <label for="inputEmail" class="col-lg-4 control-label">Select a File</label>
                    <div class="col-lg-8">
                        <?php echo form_upload(['name'=>'userfile','class'=>'td_sec form-control']); ?>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <?php if(isset($upload_error)){echo  $upload_error;} ?>
            </div>
        </div>-->
<!--        <a href="<?php echo base_url('admin/dashboard'); ?>" class="btn btn-primary">Back</a>-->
        
        <?php echo form_submit(['name' => 'Submit', 'value' => 'Submit', 'class' => 'btn1 btn-primary']); ?>
        <!-- <button type="submit" class="btn btn-primary">Submit</button> -->
        </form>
    </fieldset>
</div>
</div>
    </div>
<?php include('admin_footer.php'); ?>
