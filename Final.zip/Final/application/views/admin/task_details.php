 <?php include('admin_header.php'); ?> 
<style>
    #main{
        height: 100vh;
        width:22%;
        background:#263544;
        float: left;
        /*text-align: center;*/
    }
    #h6{
        font-size: 17px;
    }
    .row_lst{
      
        color: white;
      
    }
    .list_btn a{
        color: #fff;
        font-size: 15px;
        border: none;
    }
    .list_btn a:hover{
      transform: scale(1.1);
      transition: all 0.35s ease;
    }
    .btn{
        width:100%;
    }
    label,th,td{
        color:black;
    }
    .img_box{
        height: 80px;
        width: 80px;
        border-radius: 50%;
            display: inline-block;
    }
    #main img.logo_img{
        width: 100%;
        height: 100%;
        border-radius: 50%;
    }
    .log_div{
        padding: 10px 0px;
    }
    .log_div h6{
        display: inline-block;
        font-size: 16px;
        color: #ffffff;
    }
    .list_btn{
        width: 100%;
        display: inline-block;
    }
    .btn_clr{
        background-image: linear-gradient(to right bottom, #053730, #406469, #80949e, #c2c7cf, #ffffff);
    }
    .btn_clr i{
        margin-right: 10px;
    }
     
        .form_bg{
 width: 78%;
 display: flex;
 justify-content: center;
 float: right;
 background: rgba(182,215,237,1);
 height: 100vh;
 align-items: center;
    }
   
    .show_box h2{
        color: #000;
        text-align: center;
        font-size: 30px;
    }
    .table tr td{
        border-top: none; 
    }
    .list_btn a{
        color: #fff;
        font-size: 15px;
        border: none;
    }
    .list_btn a:hover{
      transform: scale(1.1);
      transition: all 0.35s ease;
    }
    .table tr td.td_sec{
    border: 2px solid #ddd;
    border-radius: 5px;
    display: block;
    margin-bottom: 15px;
    }
    #btn1{
      background: rgba(182,215,237,1);  
    }
    .low td{
        color:whitesmoke;
    }
     .medium td{
        color:green;
    }
    .high td{
        color:#cc0000;
    }
    .pro td{
        color:#cc0000;
    }
    .com td{
        color:black;
    }
    tr{
        border-bottom: 1px solid black;
    }
    .table{
    background-color: #fff;
    border: 1px solid #000;
    }
</style>
 <div id="main">
<div class="container">
   
    <?php if(!empty($status)){echo $status;} ?>
    <div class="log_div">
        <div class="img_box">
            <img src="<?php echo base_url("uploads/".$result2->image); ?>" class="img-responsive logo_img" alt="image">
        </div>
        
    <h6><?php echo "&nbspWelcome&nbsp".$result2->username; ?></h6>
    </div>
    
<!--    <h6 id="h6"><img src=<?php echo base_url("uploads/".$result->image); ?> width=70 height="50"><?php echo "&nbspWelcome&nbsp".$result->username; ?></h6>-->
    <div class="row_lst">
        <div class="list_btn">
            
            <a href="<?php echo base_url('profile');?>" class="btn btn-secondary btn_clr"><i class="fa fa-user-plus" aria-hidden="true"></i><span>Profile</span></a>
        </div>
    </div>
    <br>
    <div class="row_lst">
        <div class="list_btn">
            <a href="<?php echo base_url('login/userpanel');?>" class="btn btn-secondary btn_clr"><i class="fa fa-address-book"></i><span>User Panel</span></a>
        </div>
    </div>
    <br>
    <div class="row_lst">
        <div class="list_btn">
            <a href="<?php echo base_url('login/taskdetails');?>" class="btn btn-secondary btn_clr"><i class="fa fa-tasks"></i><span>Task Details</span></a>
        </div>
    </div>
    <br>
    <div class="row_lst">
        <div class="list_btn">
            <a href="<?php echo base_url('login/notification');?>" class="btn btn-secondary btn_clr"><i class="fa fa-bell"></i><span>Notification</span></a>
        </div>
    </div>
    <br>
    <div class="row_lst">
        <div class="list_btn">
            <a href="<?php echo base_url('login/request');?>" class="btn btn-secondary btn_clr"><i class="fa fa-users"></i><span>Requests</span></a>
        </div>
    </div>
    <br>
    <div class="row_lst">
        <div class="list_btn">
            <a href="<?php echo base_url('login/designation');?>" class="btn btn-secondary btn_clr"><i class="fa fa-user"></i><span>Designation</span></a>
        </div>
    </div>
</div>
</div>
<div class="form_bg">
    
<div class="container">
    <div class="show_box">
    <table class="table">
        <thead>
            <th>Sr.No.</th>
            <th>Task Title</th>
            <th>Description</th>
            <th>Assigned To</th>
            <th>Priority</th>
            <th>Progress</th>
            <th>Assigned At</th>
        </thead>
        <tbody>
             <?php $val = 1; if(count($result)){
             ?>
           
              <?php  foreach ($result as $res){ ?>
            <?php if($res->priority==="Low"){?>
           <tr class="low table"><?php }?>
            <?php if($res->priority==="Medium"){?>
           <tr class="medium table"> <?php }?>
           <?php if($res->priority==="High"){?>
            <tr class="high"><?php }?>
            <?php if($res->progress=="Completed"){ ?>
           <tr class="com"><?php }?> 
                <?php if($res->progress=="In Progress"){ ?>
           <tr class="pro"><?php }?> 
                <td><?php echo $val; ?></td>
                <td><?php echo $res->title; ?></td>
                <td><?php echo $res->description; ?></td>
                <td><?php echo $res->assigned_to; ?></td>
                <td><?php echo $res->priority; ?></td>
                <td><?php echo $res->progress; ?></td>
                <td><?php echo $res->date; ?></td>
                
            </tr>
             <?php $val++; } ?>
             <?php } else{ ?>
             <tr>
                <td colspan="3">No Records Found.</td> 
             </tr>
             <?php } ?>       
        </tbody>
    </table>
</div>
    </div>
    </div>
<?php include('admin_footer.php'); ?>  