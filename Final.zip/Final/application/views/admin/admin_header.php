 <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Panel</title>
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/bootstrap.min.css'); ?>">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
        #href1{
            margin-left: 1150px;
        }
        .head_bg{
            background-color: #263544;
            box-shadow: 0 2px 4px 0 rgba(0,0,0,0.4);
        }
        #btn1:hover{
        transform: scale(1.1);
    transition: all 0.35s ease;
    border:1px solid #263544;
    }
    </style> 
   
</head>    
<body style="background:#263544"> <!--#434954">-->  
   
   <nav class="navbar navbar-expand-lg navbar-dark  head_bg">
       <a class="navbar-brand" href="<?php echo base_url('login/dashboard') ?>">Admin Panel</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarColor01" aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarColor01">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="<?php echo base_url('login/logout') ;?>" id="href1" >Logout <span class="sr-only">(current)</span></a>
    </ul>
    
  </div>
</nav> 
