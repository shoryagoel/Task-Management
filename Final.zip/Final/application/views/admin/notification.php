<?php include('admin_header.php'); ?> 
<style>
    #main{
        height: 569px;
        width:22%;
        background:#263544;
        float: left;
        /*text-align: center;*/
    }
    #h6{
        font-size: 17px;
    }
    .row_lst{
      
        color: white;
      
    }
    #btn1:hover{
        transform: scale(1.0);
    transition: all 0.35s ease;
    border:2px solid #263544;
    }
    .btn{
        width:100%;
    }
    label,th,td{
        color:blue;
    }
    .img_box{
        height: 80px;
        width: 80px;
        border-radius: 50%;
            display: inline-block;
    }
    #main img.logo_img{
        width: 100%;
        height: 100%;
        border-radius: 50%;
    }
    .log_div{
        padding: 10px 0px;
    }
    .list_btn a{
        color: #fff;
        font-size: 15px;
        border: none;
    }
    .list_btn a:hover{
      transform: scale(1.1);
      transition: all 0.35s ease;
    }
    .log_div h6{
        display: inline-block;
        font-size: 16px;
        color: #ffffff;
    }
    .list_btn{
        width: 100%;
        display: inline-block;
    }
    .btn_clr{
        background-image: linear-gradient(to right bottom, #053730, #406469, #80949e, #c2c7cf, #ffffff);
    }
    .btn_clr i{
        margin-right: 10px;
    }.form_bg{
 width: 78%;
 
 justify-content: center;
 float: right;
 background: rgba(182,215,237,1);
 height: 100vh;
 align-items: center;
    }
    .show_box{
        margin-top: 20px;
        background-color: #fff;
    width: 100%;
    border-radius: 4px;
    margin: 40px auto;
    padding: 30px 30px;
    box-shadow: 0 2px 4px 0 rgba(0,0,0,0.4);
    }
    .show_box h2{
        color: #000;
        text-align: center;
        font-size: 30px;
    }
    .table tr td{
        border-top: none; 
    }
    .table tr td.td_sec{
    border: 2px solid #ddd;
    border-radius: 5px;
    display: block;
    margin-bottom: 15px;
    }
    #btn1{
      background: rgba(182,215,237,1);  
    }
</style>
 <div id="main">
<div class="container">
   
    <?php if(!empty($status)){echo $status;} ?>
    <div class="log_div">
        <div class="img_box">
            <img src="<?php echo base_url("uploads/".$result2->image); ?>" class="img-responsive logo_img" alt="image">
        </div>
        
    <h6><?php echo "&nbspWelcome&nbsp".$result2->username; ?></h6>
    </div>
    
<!--    <h6 id="h6"><img src=<?php echo base_url("uploads/".$result->image); ?> width=70 height="50"><?php echo "&nbspWelcome&nbsp".$result->username; ?></h6>-->
    <div class="row_lst">
        <div class="list_btn">
            
            <a href="<?php echo base_url('profile');?>" class="btn btn-secondary btn_clr"><i class="fa fa-user-plus" aria-hidden="true"></i><span>Profile</span></a>
        </div>
    </div>
    <br>
    <div class="row_lst">
        <div class="list_btn">
            <a href="<?php echo base_url('login/userpanel');?>" class="btn btn-secondary btn_clr"><i class="fa fa-address-book"></i><span>User Panel</span></a>
        </div>
    </div>
    <br>
    <div class="row_lst">
        <div class="list_btn">
            <a href="<?php echo base_url('login/taskdetails');?>" class="btn btn-secondary btn_clr"><i class="fa fa-tasks"></i><span>Task Details</span></a>
        </div>
    </div>
    <br>
    <div class="row_lst">
        <div class="list_btn">
            <a href="<?php echo base_url('login/notification');?>" class="btn btn-secondary btn_clr"><i class="fa fa-bell"></i><span>Notification</span></a>
        </div>
    </div>
    <br>
    <div class="row_lst">
        <div class="list_btn">
            <a href="<?php echo base_url('login/request');?>" class="btn btn-secondary btn_clr"><i class="fa fa-users"></i><span>Requests</span></a>
        </div>
    </div>
    <br>
    <div class="row_lst">
        <div class="list_btn">
            <a href="<?php echo base_url('login/designation');?>" class="btn btn-secondary btn_clr"><i class="fa fa-user"></i><span>Designation</span></a>
        </div>
    </div>
</div>
</div>
<div class="form_bg">
<div class="container">
    <div class="show_box">
    <?php echo anchor("login/add_notification",'Add Notification',['class'=>"btn btn-primary",'id'=>'btn1']); ?>
    <?php if(!empty($status)){ echo $status ; }?>
    <?php if(!empty($success)){ echo $success ; }?>
    <table class="table">
        <thead>
            <th>Sr.No.</th>
            <th>Title</th>
            <th>Description</th>
            <th>Posted At</th>
            <th>Action</th>
        </thead>
        <tbody>
        
             <?php $val = 1; if(count($result)){?>
              <?php  foreach ($result as $res){ ?>
            <tr>
                <td><?php echo $val; ?></td>
                <td><?php echo $res->title; ?></td>
                <td><?php echo $res->body; ?></td>
                <td><?php echo $res->create_at;?></td>
                <td>
                    <div class="row">
                        <div class="col-lg-5">
                            <?php echo anchor("login/editnotification/{$res->id}",'Edit',['class'=>"btn btn-primary"]); ?>
                        </div>
                    
                        <div class="col-lg-6">
                            <?php echo form_open('login/deletenotification');
                            echo form_hidden('notification_id',$res->id);
                            echo form_submit(['name'=>'submit','value'=>'Delete','class'=>'btn btn-danger','onclick'=>"return confirm('Are you sure?')"]);
                            echo form_close();?>
                        </div>
                    </div>
                    </div>
                </td>
            </tr>
             <?php $val++; } ?>
             <?php } else{ ?>
             <tr>
                <td colspan="3">No Records Found.</td> 
             </tr>
             <?php } ?>       
        </tbody>
    </table>
</div>
    </div>
</div>
<?php include('admin_footer.php'); ?>  