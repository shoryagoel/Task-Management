<?php include('admin_header.php'); ?>

<style>
    #main{
        height: 100vh;
        width:22%;
        background:#263544;
        float: left;
        /*text-align: center;*/
    }
    
    .row_lst{     
        color: white;
    }
    #btn1:hover{
        transform: scale(1.1);
    transition: all 0.35s ease;
    border:1px solid #263544;
    }
    .btn{
        width:100%;
    }
    .log_div h6{
        font-size: 18px;
        text-align: center;
        display:block;
    }
    .list_btn a{
        color: #fff;
        font-size: 15px;
        border: none;
    }
    .list_btn a:hover{
      transform: scale(1.1);
      transition: all 0.35s ease;
    }
    label,th,td{
        color:whitesmoke;
    }
    .img_box{
        height: 80px;
        width: 80px;
        border-radius: 50%;
            display: inline-block;
    }
    #main img.logo_img{
        width: 100%;
        height: 100%;
        border-radius: 50%;
    }
    .log_div{
        padding: 10px 0px;
    }
    
    .list_btn{
        width: 100%;
        display: inline-block;
    }
    .btn_clr{
        background-image: linear-gradient(to right bottom, #053730, #406469, #80949e, #c2c7cf, #ffffff);
    }
    .list_btn a{
        color: #fff;
        font-size: 15px;
        border: none;
    }
    .list_btn a:hover{
      transform: scale(1.1);
      transition: all 0.35s ease;
    }
    .btn_clr i{
        margin-right: 10px;
    }
    .bg_image{
     width: 78%;
    float: right;
    }
    .bg_image img{
    width: 100%;
    height: 100vh;
    }
    .form_bg{
    width: 78%;
    display: flex;
    justify-content: center;
    float: right;
    background: rgba(182,215,237,1);
    align-items: center;
    padding: 20px 0px;
    }
    .show_box{
        background-color: #fff;
    width: 500px;
    border-radius: 4px;
    margin: 0 auto;
    padding: 30px 30px;
    box-shadow: 0 2px 4px 0 rgba(0,0,0,0.4);
    }
    .show_box h2{
        color: #000;
        text-align: center;
        font-size: 30px;
    }
    .table tr td{
        color:black;
        border-top: none; 
    }
    .table tr td.td_sec{
    border: 2px solid #ddd;
    border-radius: 5px;
    display: block;
    margin-bottom: 15px;
    }
    #btn1{
      background: rgba(182,215,237,1);  
    }
    #btn1:hover{
        transform: scale(1.1);
    transition: all 0.35s ease;
    border:1px solid #263544;
    }
    
</style>
 <div id="main">
<div class="container">
   
    <?php if(!empty($status)){echo $status;} ?>
    <div class="log_div">
    <h6><?php echo "&nbspWelcome&nbsp".$result->name; ?></h6>
    </div>
    
    <div class="row_lst">
        <div class="list_btn">    
            <a href="<?php echo base_url('user/profile');?>" class="btn btn-secondary btn_clr"><i class="fa fa-user-plus" aria-hidden="true"></i><span>Profile</span></a>
        </div>
    </div>
    <br>
    <div class="row_lst">
        <div class="list_btn">
            <a href="<?php echo base_url('user/taskdetails');?>" class="btn btn-secondary btn_clr"><i class="fa fa-address-book"></i><span>My Tasks</span></a>
        </div>
    </div>
    <br>
    <div class="row_lst">
        <div class="list_btn">
            <a href="<?php echo base_url('user/assigned_task');?>" class="btn btn-secondary btn_clr"><i class="fa fa-tasks"></i><span>Task Details</span></a>
        </div>
    </div>
    <br>
    <div class="row_lst">
        <div class="list_btn">
            <a href="<?php echo base_url('user/completed_task');?>" class="btn btn-secondary btn_clr"><i class="fa fa-list"></i><span>Completed Tasks</span></a>
        </div>
    </div>
    
    <br>
    <div class="row_lst">
        <div class="list_btn">
            <a href="<?php echo base_url('user/notification');?>" class="btn btn-secondary btn_clr"><i class="fa fa-bell"></i><span>Notifications</span></a>
        </div>
    </div>
    <br>
    <div class="row_lst">
        <div class="list_btn">
            <a href="<?php echo base_url('user/request_send');?>" class="btn btn-secondary btn_clr"><i class="fa fa-users"></i><span>Requests</span></a>
        </div>
    </div>
</div>
</div>

<div class="form_bg">
<div class="container1">
    <div class="show_box">
    <h2>Profile</h2>
   <table class="table">
        <tbody>
            <tr>
                <td>Username:</td>
                <td class="td_sec"><?php echo $result->name; ?></td>
            </tr>
            <tr>
                <td>Gender:</td>
                <td class="td_sec"><?php echo $result->gender;?></td>
            </tr>
            <tr>
                <td>Designation:</td>
                <td class="td_sec"><?php echo $result->designation; ?></td>
            </tr>
            <tr>
                <td>DOB:</td>
                <td class="td_sec"><?php echo $result->dob; ?></td>
            </tr>
            <tr>
                <td>City:</td>
                <td class="td_sec"><?php echo $result->city; ?></td>
            </tr>
            <tr>
                <td>Permanent Address:</td>
                <td class="td_sec"><?php echo $result->permanent_address; ?></td>
            </tr>
            <tr>
                <td>Temporary Address:</td>
                <td class="td_sec"><?php echo $result->temporary_address; ?></td>
            </tr>
            <tr>
                <td>Email:</td>
                <td class="td_sec"><?php echo $result->email; ?></td>
            </tr>
            
<!--            <tr>
                <td>
                    <?php echo anchor("login/editprofile/{$result->id}",'Edit',['class'=>"btn btn-primary",'id'=>'btn1']); ?>
                </td>
            </tr>       -->
        </tbody>
    </table>
</div>
</div>
    </div>
<?php include('admin_footer.php'); ?>