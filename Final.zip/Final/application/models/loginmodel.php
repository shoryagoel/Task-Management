<?php
class Loginmodel extends CI_Model{
    public function login_valid( $username, $password ){
        $email = $this->input->post('username');
        $q =  $this->db->where(['username'=>$username,'password'=>$password])
                       ->get('admin');
        if($q->num_rows()){
            $this->session->set_userdata('log','admin');
            return $q->row()->id;
        }
        $block = 0;
        $query = $this->db->where(['email'=>$email,'password'=>$password,'block'=>$block])
                          ->get('employee');
        if($query->num_rows()){
            $this->session->set_userdata('log','employee');
            return $query->row()->employee_id;
        }
        else{
            return FALSE;
        }    
    }
    
    public function profile_load() {
        $id = $this->session->userdata('user_id');
        $q = $this->db->where('id',$id)
                      ->get('admin');
              return $q->row();
    }
    
    public function dashboard() {
     $id = $this->session->userdata('user_id');   
     $q = $this->db->where('id',$id)
                      ->get('admin');
              return $q->row();
    }
    
    public function users() {
        $q = $this->db->query("select employee_id,e.name,gender,d.name as designation,dob,city,permanent_address,temporary_address,email,password,block 
                                from employee e,designation d where e.designation=d.id");
        return $q->result();
    }
    
    public function get_designation() {
        $q  = $this->db->get('designation');
               return $q->result();
    }
    
    public function add_user(){
        $data = [
            'name' => $this->input->post('name'),
            'gender' => $this->input->post('gender'),
            'designation' => $this->input->post('designation'),
            'dob' => $this->input->post('dob'),
            'city' => $this->input->post('city'),
            'permanent_address' => $this->input->post('permanent_address'),
            'temporary_address' => $this->input->post('temporary_address'),
            'email' => $this->input->post('email'),
            'password' => $this->input->post('password')
        ];
        $this->db->insert('employee',$data);
        return $this->db->insert_id();
    }
    
    public function edit_profile($id) {
        $q = $this->db->where('id',$id)
                 ->get('admin');
         return $q->row();
    }
    public function update_profile($id,$data,$file) {
        if($file==""){
            $q = $this->db->where('id',$id)
                      ->update('admin',$data);
        }else{
        $data['image']=$file;
            $q = $this->db->where('id',$id)
                      ->update('admin',$data);
        }
        return $q;
    }
    public function get_task_details() {
        $q = $this->db->query("Select title,description,e.name as assigned_to,priority,progress,date from task t,employee e where e.employee_id=t.assigned_to order by priority");
       // $q = $this->db->get('task');
        return $q->result();
    }
    
    public function delete_user($employee_id){
        $q = $this->db->delete('employee',['employee_id'=>$employee_id]);
        return $q;
    }
    
    public function edit_user($employee_id) {
        $q = $this->db->query("select employee_id,e.name as name,gender,d.id as id,d.name as designation,dob,city,permanent_address,temporary_address,email,password,block 
                                from employee e,designation d where e.designation=d.id and e.employee_id=$employee_id");
        return $q->row();
    }
    public function edit_user_designation(){
    $q = $this->db->get('designation');
        return $q->result();
    }
    public function update_user($employee_id) {
        $data = [
            'name' => $this->input->post('name'),
            'gender' => $this->input->post('gender'),
            'designation' => $this->input->post('designation'),
            'dob' => $this->input->post('dob'),
            'city' => $this->input->post('city'),
            'permanent_address' => $this->input->post('permanent_address'),
            'temporary_address' => $this->input->post('temporary_address'),
            'email' => $this->input->post('email'),
            'password' => $this->input->post('password')
        ];
        $q = $this->db->where('employee_id',$employee_id)
                 ->update('employee',$data);
        return $q;
    }
    
   public function get_notification(){
       $q = $this->db->get('notification');
       return $q->result();  
   }
   
   public function do_add_notification() {
       $data = [
           'title' => $this->input->post('title'),
           'body'  => $this->input->post('body')
       ];
       $q = $this->db->insert('notification',$data);
       return $this->db->insert_id();
   }
   public function delete_notification($id) {
       $q = $this->db->delete('notification',['id'=>$id]);
       return $q;
   }
   public function edit_notification($id) {
       $q = $this->db->get('notification');
       return $q->row();
   }
   
   public function do_update_notification($id) {
       $data = [
           'title' => $this->input->post('title'),
           'body' => $this->input->post('body')
       ];
       $q = $this->db->where('id',$id)
                     ->update('notification',$data);
       return $q;
   }
   public function request(){
       $id = $this->session->userdata('user_id');
       $q = $this->db->query("select subject,description,e.name as name,date from request r,employee e
               where r.by=e.employee_id and r.to=$id");
       return $q->result();
   }
   public function block($employee_id,$block){
       
       $q = $this->db->query("update employee set block = $block where employee_id=$employee_id");
       return $q;
   }
   
   public function designation() {
       $q = $this->db->get('designation');
       return $q->result();
   }
   public function add_designation() {
       $this->db->insert('designation',['name'=> $this->input->post('name')]);
//       $this->db->query("INSERT INTO designation (name) VALUES '$name' ");
       return $this->db->insert_id();
   }
   public function get_edit_desig($id) {
    $q = $this->db->where('id',$id)
                   ->get('designation');
        return $q->row();
   }
   public function update_desig($id){
       $data = [
           'name' => $this->input->post('name')
       ];
       $this->db->update('designation',$data,['id'=>$id]);
       return $this->db->affected_rows();
   }
   public function delete_designation($id) {
       $q = $this->db->where('id',$id)
                     ->delete('designation');
       return $q;
   }
}
?>

